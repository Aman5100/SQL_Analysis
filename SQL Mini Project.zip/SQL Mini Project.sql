CREATE DATABASE ecommerce_db;
USE ecommerce_db;

CREATE TABLE customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL CHECK (price > 0),
    stock_quantity INT NOT NULL DEFAULT 0,
    added_on DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'Pending',
    total_amount DECIMAL(10,2),
    CONSTRAINT fk_orders_customers
        FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
);
CREATE TABLE order_items (
    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT NOT NULL CHECK (quantity > 0),
    item_price DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_orderitems_orders
        FOREIGN KEY (order_id)
        REFERENCES orders(order_id),
    CONSTRAINT fk_orderitems_products
        FOREIGN KEY (product_id)
        REFERENCES products(product_id)
);
CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    amount_paid DECIMAL(10,2) NOT NULL CHECK (amount_paid > 0),
    method VARCHAR(20) NOT NULL,
    CONSTRAINT fk_payments_orders
        FOREIGN KEY (order_id)
        REFERENCES orders(order_id)
);
CREATE TABLE product_reviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT,
    customer_id INT,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    review_text TEXT,
    review_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reviews_products
        FOREIGN KEY (product_id)
        REFERENCES products(product_id),
    CONSTRAINT fk_reviews_customers
        FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
);
SHOW TABLES;
INSERT INTO customers (name, email, phone) VALUES
('Aman Pattanaik', 'aman@gmail.com', '9876543210'),
('Rohit Sharma', 'rohit@gmail.com', '9123456789'),
('Ananya Verma', 'ananya@gmail.com', '9988776655'),
('Kunal Mehta', 'kunal@gmail.com', '9090909090'),
('Sneha Iyer', 'sneha@gmail.com', '9898989898');

INSERT INTO products (name, category, price, stock_quantity) VALUES
('Bluetooth Speaker', 'Electronics', 2499.00, 50),
('Wireless Mouse', 'Electronics', 799.00, 100),
('Laptop Backpack', 'Accessories', 1499.00, 40),
('Smart Watch', 'Electronics', 3999.00, 30),
('Water Bottle', 'Home & Kitchen', 499.00, 80),
('Noise Cancelling Headphones', 'Electronics', 5999.00, 20);

INSERT INTO orders (customer_id, status) VALUES
(1, 'Shipped'),
(2, 'Delivered'),
(3, 'Pending'),
(1, 'Delivered'),
(4, 'Shipped');

INSERT INTO order_items (order_id, product_id, quantity, item_price) VALUES
(1, 1, 2, 2499.00),
(1, 2, 1, 799.00),
(2, 4, 1, 3999.00),
(3, 3, 2, 1499.00),
(4, 6, 1, 5999.00),
(5, 5, 3, 499.00);

INSERT INTO payments (order_id, amount_paid, method) VALUES
(1, 5797.00, 'UPI'),
(2, 3999.00, 'Credit Card'),
(4, 5999.00, 'Debit Card'),
(5, 1497.00, 'UPI');

INSERT INTO product_reviews (product_id, customer_id, rating, review_text) VALUES
(1, 1, 5, 'Excellent sound quality'),
(2, 2, 4, 'Good value for money'),
(4, 3, 5, 'Very useful and accurate'),
(6, 4, 4, 'Noise cancellation works well'),
(5, 5, 3, 'Decent product for daily use');

SET SQL_SAFE_UPDATES = 0;
UPDATE orders o
SET total_amount = (
    SELECT SUM(quantity * item_price)
    FROM order_items oi
    WHERE oi.order_id = o.order_id
);
SET SQL_SAFE_UPDATES = 1;

SELECT name, email FROM customers;
SELECT * FROM products;
SELECT DISTINCT category FROM products;
SELECT * FROM products WHERE price > 1000;
SELECT * FROM products WHERE price BETWEEN 2000 AND 5000;
SELECT * FROM customers WHERE customer_id IN (1,2,3);
SELECT * FROM customers WHERE name LIKE 'A%';
SELECT * FROM products WHERE category='Electronics' AND price < 3000;
SELECT name, price FROM products ORDER BY price DESC;
SELECT name, price FROM products ORDER BY price DESC, name;

SELECT * FROM orders WHERE customer_id IS NULL;
SELECT name AS Customer_Name, email AS Email FROM customers;
SELECT order_item_id, quantity * item_price AS item_total FROM order_items;
SELECT CONCAT(name,' - ',phone) AS contact FROM customers;
SELECT order_id, DATE(order_date) FROM orders;
SELECT * FROM products WHERE stock_quantity = 0;

SELECT COUNT(*) FROM orders;
SELECT SUM(total_amount) FROM orders;
SELECT AVG(total_amount) FROM orders;
SELECT COUNT(DISTINCT customer_id) FROM orders;
SELECT customer_id, COUNT(order_id) FROM orders GROUP BY customer_id;
SELECT customer_id, SUM(total_amount) FROM orders GROUP BY customer_id;
SELECT p.category, SUM(oi.quantity)
FROM products p JOIN order_items oi ON p.product_id = oi.product_id
GROUP BY p.category;
SELECT category, AVG(price) FROM products GROUP BY category;
SELECT DATE(order_date), COUNT(*) FROM orders GROUP BY DATE(order_date);
SELECT method, SUM(amount_paid) FROM payments GROUP BY method;

SELECT o.order_id, c.name FROM orders o JOIN customers c ON o.customer_id=c.customer_id;
SELECT DISTINCT p.name FROM products p JOIN order_items oi ON p.product_id=oi.product_id;
SELECT o.order_id, p.method FROM orders o JOIN payments p ON o.order_id=p.order_id;
SELECT c.name, o.order_id FROM customers c LEFT JOIN orders o ON c.customer_id=o.customer_id;
SELECT p.name, oi.quantity FROM products p LEFT JOIN order_items oi ON p.product_id=oi.product_id;
SELECT p.payment_id, o.order_id FROM orders o RIGHT JOIN payments p ON o.order_id=p.order_id;

SELECT * FROM products WHERE price > (SELECT AVG(price) FROM products);
SELECT * FROM customers WHERE customer_id IN (SELECT customer_id FROM orders);
SELECT * FROM orders o
WHERE total_amount > (
    SELECT AVG(total_amount) FROM orders WHERE customer_id=o.customer_id
);
SELECT * FROM customers WHERE customer_id NOT IN (SELECT customer_id FROM orders);
SELECT * FROM products WHERE product_id NOT IN (SELECT product_id FROM order_items);
SELECT customer_id, MAX(total_amount) FROM orders GROUP BY customer_id;
SELECT c.name, MAX(o.total_amount)
FROM customers c JOIN orders o ON c.customer_id=o.customer_id
GROUP BY c.name;

SELECT customer_id FROM orders
UNION
SELECT customer_id FROM product_reviews;

SELECT DISTINCT o.customer_id
FROM orders o JOIN product_reviews r
ON o.customer_id = r.customer_id;

#IMPORTANT OUTPUTS OF THE PROJECT:

#Customer & Order Insights
#Identified active customers who placed one or more orders
#Found repeat customers and their total spending
#Listed customers who never placed any orders

#Sales & Revenue Analysis
#Calculated total revenue from all orders
#Measured average order value
#Identified highest value order per customer

#Order & Payment Analysis
#Tracked number of orders per day
#Analyzed preferred payment methods (UPI, Credit Card, etc.)
#Mapped orders with their corresponding payments
